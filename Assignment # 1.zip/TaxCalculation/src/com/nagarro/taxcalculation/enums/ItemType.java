package com.nagarro.taxcalculation.enums;

public enum ItemType {
	Raw,Manufactured,Import
}
